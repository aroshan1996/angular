import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  user: boolean = false;
  loggedIn: any;
  constructor(private authservice: AuthService, private route: Router) {}

  ngOnInit(): void {
    // if(localStorage.getItem('token')){
    //   debugger
    //   this.authservice.loggedIn.subscribe(data=>this.loggedIn=data)
    // }

    this.route.events.subscribe((event) => console.log(event));
  }
  logout() {
    // this.authservice.loggedIn.subscribe(data=>this.loggedIn="")
    this.loggedIn = '';
    localStorage.removeItem('token');
  }
}
